#include <stdio.h>
#include <ncurses.h>
#include <time.h>
#include <stdlib.h>
#include <unistd.h>

#define DOG_Y 15
#define DOG_X 20
#define POOP_Y 20 
#define POOP_X 40

bool jump;

void dog_shape(int x, int y){
	move(y, x);
	if(!jump){
		printw("o      oooo\n");
		printw("oo    oooooo\n");
    		printw("ooooooooooo\n");
   		printw(" oooooooooo\n");
		printw(" ooo   ooo\n");
		printw("  ooo  oo\n");
		printw("   oo  oo\n");
	}else{
		printw("   o   oooo\n");
		printw(" oo   oooooo\n");
    		printw("ooooooooooo\n");
   		printw(" oooooooooo\n");
		printw(" ooo   ooo\n");
		printw("oo      oo\n");
		printw("oo       oo\n");
	}
}

void poop_shape(int x, int y){
	mvprintw(y++, x, "  o \n");
	mvprintw(y++, x, " ooo \n");
	mvprintw(y++, x, "ooooo\n");
}

int main(void){
	initscr();
	int ch;

	while(1){
		int dog_y = DOG_Y;
		int dog_x = DOG_X;
		int poop_y = POOP_Y;
		int poop_x = POOP_X;
		int score = 0;
		jump = false;
		bool bottom = true;
		time_t ttime = time(NULL);
		int jump_y = dog_y-5; 

		while(1){
			nodelay(stdscr, TRUE);
			ch = getch();
			if(ch == ' ' && bottom){
				if(poop_y == POOP_Y){
					if(dog_y <= jump_y){
						break;
					}
					jump = true;
					bottom = false;
				} 
			}

			poop_x -= 2;
			if(poop_x <= 0){
				poop_x = POOP_X;
			}
			clear();
			
			if(jump){
				dog_y--;
			}else{
				dog_y++;
			}

			if(dog_y >= 16){
				dog_y = 16;
				bottom = true;
			}

			if(dog_y <= 11){
				jump = false;
			}

			dog_shape(0, dog_y);
			poop_shape(poop_x, POOP_Y);
	
			if(poop_x <= 8 && poop_x >= 7){
				refresh();
				if(!jump){
					break;
				}
			}

			if(poop_x == dog_x){
				ttime = time(NULL);
				score++;
			}
	
			mvprintw(0, 0, "------------------------------PRESENT SCORE: %d---------------------------------", score);
			mvprintw(23, 0, "-------------------------------------------------------------------------------");
			mvprintw(2, 0, "+       +       +       +       +       +");	
			mvprintw(3, 0, "    +       +       +       +       +       +                        +      +      +      +");	
			mvprintw(4, 0, "+       +       +       +       +       +                        +      +      +      +");	
			mvprintw(5, 0, "    +       +       +       +       +       +                        +      +      +      +");	
			mvprintw(6, 0, "+       +       +       +       +       +                        +      +      +      +");	
			mvprintw(7, 0, "    +       +       +       +       +       +       +       +       +       +");	
			mvprintw(8, 0, "+       +       +       +       +       +       +       +       +       +");	
			mvprintw(9, 0, "    +       +       +       +       +       +       +       +       +       +");	
			mvprintw(10, 0, "+       +       +       +       +       +       +       +       +       +");	
			mvprintw(11, 0, "    +       +       +       +       +       +       +       +       +       +");	
			mvprintw(2, 40, "+++JumpKey: <space>+++");
			mvprintw(3, 40, "|  Jump              |");
			mvprintw(4, 40, "|      and           |");
			mvprintw(5, 40, "|         avoid      |");
			mvprintw(6, 40, "|              poop  |");
			mvprintw(7, 40, "++++++++++++++++++++++");
			refresh();
			napms(1000/15);
		}
		mvprintw(0, 0, "-------------------------------------------------------------------------------");
		mvprintw(3, 27, " ____________________\n");
		mvprintw(4, 27, "|                    |\n");
		mvprintw(5, 27, "|        GAME        |\n");
		mvprintw(6, 27, "|        OVER        |\n");
		mvprintw(7, 27, "|____________________|\n");
		mvprintw(9, 29, "[FINAL SCORE: %d]", score);
		mvprintw(11, 0, "-------------------------------------------------------------------------------");
		mvprintw(13, 13, ">> PRESS key 'q': the game will be terminated.");
	       	mvprintw(14, 13, ">> PRESS 'any key' except 'q': the game will be restarted."); 	
		mvprintw(21, 15, "<<----------------dog touched poop!!");

		nodelay(stdscr, FALSE);
		ch = getch();
		if(ch == 'q'){
			break;
		}
	}

	endwin();
	return 0;
}

			
		
		
		
