#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <pthread.h>
#include <ncurses.h>

#define PORTNUM 9000
#define HEIGHT 15
#define WIDTH 55
#define DOG_Y 15
#define DOG_X 20
#define POOP_Y 20 
#define POOP_X 40

bool jump;

void dog_shape(int x, int y){
	move(y, x);
	if(!jump){
		printw("o      oooo\n");
		printw("oo    oooooo\n");
    		printw("ooooooooooo\n");
   		printw(" oooooooooo\n");
		printw(" ooo   ooo\n");
		printw("  ooo  oo\n");
		printw("   oo  oo\n");
	}else{
		printw("   o   oooo\n");
		printw(" oo   oooooo\n");
    		printw("ooooooooooo\n");
   		printw(" oooooooooo\n");
		printw(" ooo   ooo\n");
		printw("oo      oo\n");
		printw("oo       oo\n");
	}
}

void poop_shape(int x, int y){
	mvprintw(y++, x, "  o \n");
	mvprintw(y++, x, " ooo \n");
	mvprintw(y++, x, "ooooo\n");
}


char sbuf[256], rbuf[256];
int sd;
int rlen;
int r = 2, c = 2;
int cnt = 0;
WINDOW *win;

void *recv_func(void *arg){
	while(1){
		memset(rbuf, '\0', sizeof(rbuf));
		rlen = recv(sd, rbuf, sizeof(rbuf), 0);
		if(strncmp(rbuf, "exit", 4) == 0)
			exit(0);
		if(rlen > 0){
	
			if(r >= 14){
				r = 1;
				wclear(win);
			}
			wmove(win, r++, c);
			wprintw(win, "server: ");
			wprintw(win, "%s", rbuf);
			wrefresh(win);
		}
		
	}
}

void *send_func(void *arg){
	while(1){
		memset(sbuf, '\0', sizeof(sbuf));
		
		move(30, 2);
		printw("client: ");
		scanw("%s", sbuf);
		sbuf[strlen(sbuf)] = '\0';
		
		if(send(sd, sbuf, strlen(sbuf), 0) == -1){
			perror("send");
			exit(1);
		}
		
		if(r >= 14){
			r = 2;
			wclear(win);
		}
		move(r++, c);
		refresh();
		if(strncmp(sbuf, "exit", 4) == 0)
			exit(0);
	}
}

int startx = 0;
int starty = 0;

int main(){
	char menu[256] = {0,};
	struct sockaddr_in sin;
	pthread_t pth1, pth2;

	if((sd = socket(AF_INET, SOCK_STREAM, 0)) == -1){
		perror("socket");
		exit(1);
	}
	memset((char *)&sin, '\0', sizeof(sin));
	sin.sin_family = AF_INET;
	sin.sin_port = htons(PORTNUM);
	sin.sin_addr.s_addr = inet_addr("127.0.0.1");

	if(connect(sd, (struct sockaddr *)&sin, sizeof(sin))){
		perror("connet");
		exit(1);
	}

	memset(menu, '\0', sizeof(menu));
	//Receive a list of available services from server
	recv(sd, menu, sizeof(menu), 0);
	printf("%s", menu);

	memset(menu, '\0', sizeof(menu));
	printf("Enter the number: ");
	fgets(menu, sizeof(menu), stdin);
	//Send client's desired service number
	send(sd, menu, strlen(menu)+1, 0);

	if(!strncmp(menu, "1", 1)){
		
		initscr();
		cbreak;
		echo();
		curs_set(0);

		start_color();
		init_pair(1, COLOR_GREEN, COLOR_BLACK);
		bkgd(COLOR_PAIR(1));
		
		win = newwin(HEIGHT, WIDTH, starty, startx);
		refresh();
		mvwprintw(win, 1, 1, "======chatting start==============\n");

		box(win, 0, 0);
		scrollok(win, TRUE);
		wrefresh(win);

		pthread_create(&pth1, NULL, send_func, NULL);
		pthread_create(&pth2, NULL, recv_func, NULL);

		pthread_join(pth1, NULL);
		pthread_join(pth2, NULL);
	}
	if(!strncmp(menu, "2", 1)){
		printf("=====game 1=====\n");

//		printf(shape[0][0]);
		while(1){
			memset(sbuf, '\0', sizeof(sbuf));
			printf("rock, sissor, paper: ");
			scanf("%s", sbuf);
			
			if(send(sd, sbuf, strlen(sbuf)+1, 0) == -1){
				perror("send");
				exit(1);
			}
			
			memset(rbuf, '\0', sizeof(rbuf));
			rlen = recv(sd, rbuf, sizeof(rbuf), 0);
			printf("SERVER: %s\n", rbuf);

			if((!(strcmp(sbuf, "rock")) && !(strcmp(rbuf, "sissor"))) || ((!strcmp(sbuf, "sissor")) && !(strcmp(rbuf, "paper"))) || ((!strcmp(sbuf, "paper")) && !(strcmp(rbuf, "rock")))){
			 	printf("=====CLIENT WIN!=====\n");
				sleep(1);
				exit(1);
			}else if((!(strcmp(sbuf, "rock")) && !(strcmp(rbuf, "paper"))) || ((!strcmp(sbuf, "sissor")) && !(strcmp(rbuf, "rock"))) || ((!strcmp(sbuf, "paper")) && !(strcmp(rbuf, "sissor")))){
			 	printf("=====CLIENT LOSE!=====\n");
				sleep(1);
				exit(1);
			}else if((!(strcmp(sbuf, "rock")) && !(strcmp(rbuf, "rock"))) || ((!strcmp(sbuf, "sissor")) && !(strcmp(rbuf, "sissor"))) || ((!strcmp(sbuf, "paper")) && !(strcmp(rbuf, "paper")))){

				printf("=====EVEN: PLAY AGAIN!=====\n");
				sleep(1);
			}else{
				printf("=====THAT IS NOT CORRECT RSP!=====\n");
				sleep(1);
			}
		}
		sleep(1);
		close(sd);
	}
	if(!strncmp(menu, "3", 1)){
		printf("=====game 2=====\n");
		initscr();
		int ch;

		while(1){
			int dog_y = DOG_Y;
			int dog_x = DOG_X;
			int poop_y = POOP_Y;
			int poop_x = POOP_X;
			int score = 0;
			jump = false;
			bool bottom = true;
			time_t ttime = time(NULL);
			int jump_y = dog_y-5; 

			while(1){
				nodelay(stdscr, TRUE);
				ch = getch();
				if(ch == ' ' && bottom){
					if(poop_y == POOP_Y){
						if(dog_y <= jump_y){
							break;
						}
						jump = true;
						bottom = false;
					} 
				}

				poop_x -= 2;
				if(poop_x <= 0){
					poop_x = POOP_X;
				}
				clear();
				
				if(jump){
					dog_y--;
				}else{
					dog_y++;
				}
	
				if(dog_y >= 16){
					dog_y = 16;
					bottom = true;
				}
	
				if(dog_y <= 11){
					jump = false;
				}
	
				dog_shape(0, dog_y);
				poop_shape(poop_x, POOP_Y);
		
				if(poop_x <= 8 && poop_x >= 7){
					refresh();
					if(!jump){
						break;
					}
				}
	
				if(poop_x == dog_x){
					ttime = time(NULL);
					score++;
				}
		
				mvprintw(0, 0, "------------------------------PRESENT SCORE: %d---------------------------------", score);
				mvprintw(23, 0, "-------------------------------------------------------------------------------");
				mvprintw(2, 0, "+       +       +       +       +       +");	
				mvprintw(3, 0, "    +       +       +       +       +       +                        +      +      +      +");	
				mvprintw(4, 0, "+       +       +       +       +       +                        +      +      +      +");	
				mvprintw(5, 0, "    +       +       +       +       +       +                        +      +      +      +");	
				mvprintw(6, 0, "+       +       +       +       +       +                        +      +      +      +");	
				mvprintw(7, 0, "    +       +       +       +       +       +       +       +       +       +");	
				mvprintw(8, 0, "+       +       +       +       +       +       +       +       +       +");	
				mvprintw(9, 0, "    +       +       +       +       +       +       +       +       +       +");	
				mvprintw(10, 0, "+       +       +       +       +       +       +       +       +       +");	
				mvprintw(11, 0, "    +       +       +       +       +       +       +       +       +       +");	
				mvprintw(2, 40, "+++JumpKey: <space>+++");
				mvprintw(3, 40, "|  Jump              |");
				mvprintw(4, 40, "|      and           |");
				mvprintw(5, 40, "|         avoid      |");
				mvprintw(6, 40, "|              poop  |");
				mvprintw(7, 40, "++++++++++++++++++++++");
				refresh();
				napms(1000/15);
			}
			mvprintw(0, 0, "-------------------------------------------------------------------------------");
			mvprintw(3, 27, " ____________________\n");
			mvprintw(4, 27, "|                    |\n");
			mvprintw(5, 27, "|        GAME        |\n");
			mvprintw(6, 27, "|        OVER        |\n");
			mvprintw(7, 27, "|____________________|\n");
			mvprintw(9, 29, "[FINAL SCORE: %d]", score);
			mvprintw(11, 0, "-------------------------------------------------------------------------------");
			mvprintw(13, 13, ">> PRESS key 'q': the game will be terminated.");
	       		mvprintw(14, 13, ">> PRESS 'any key' except 'q': the game will be restarted."); 	
			mvprintw(21, 15, "<<----------------dog touched poop!!");
			memset(sbuf, '\0', sizeof(sbuf));
			sprintf(sbuf, "%d", score);
			if(send(sd, sbuf, strlen(sbuf)+1, 0) == -1){
				perror("send");
				exit(1);
			}
			
			memset(rbuf, '\0', sizeof(rbuf));
			
			rlen = recv(sd, rbuf, sizeof(rbuf), 0);
			
			if(score > atoi(sbuf)){
				mvprintw(1, 30, "RESULT: YOU WIN!\n");
			}else if(score == atoi(sbuf)){
				mvprintw(1, 30, "RESULT: YOU EVEN!\n");
			}else{
				mvprintw(1, 30, "RESULT: YOU LOSE..\n");
			}
			refresh();
			nodelay(stdscr, FALSE);
			ch = getch();
			if(ch == 'q'){
				break;
			}
		}
		endwin();
		sleep(1);
		close(sd);
	}
	endwin();
	close(sd);
}

