#include <stdio.h>
#include <stdlib.h>
#include <ncurses.h>

#define WIDTH 70
#define HEIGHT 70

int startx = 0;
int starty = 0;

void *send_msg(void *arg){
	int sd = *((int*)arg);
	int len;
	own.who = P;
	while(1){
		own.p_col = col;
		own.p_row = row;
		write(sd, (void*)&own, sizeof(own));
		sleep(0.5);
	}
	return NULL;
}

void* recv_msg(void *arg){
	int sd = *((int*)arg);
	char result[500];
	int str_len;
	int past_r, past_c;

	while(1){
		str_len = read(sd, (void*)&data, sizeof(data));
		start = 1;
		own.t_col = data.t_col;
		own.t_row = data.t_row;
		own.win = data.win;

		if(own.win != 1){
			signal(SIGALRM, SIG_IGN);
			if(own.win == T){
				clear();
				fail(stdscr);
				break;
			}else if(own.win == P){
				clear();
				winner(stdscr);
				break;
			}
		}
		MAP[past_r][past_c] = ' ';

		past_r = data.p_row;
		past_c = data.p_col;
		MAP[past_r][past_c] = 'T';
	}
	return NULL;
}

int main(int argc, char *argv[]){
	int sd;
	struct sockaddr_int ser;
	int slen = sizeof(ser);
	pthread_t snd_thread, rcv_thread, gb_thread, signal_thread;

	if(argc != 3){
		printf("ENTER TO PORTNUM AND IP-ADDRESS");
		exit(1);
	}
	if((sd = socket(AF_INET, SOCK_STREAM, 0)) == -1){
		perror("socket");
		exit(1);
	}

	memset((char *)&ser, '\0', sizeof(ser));
	ser.sin_family = AF_INET;
	ser.sin_port = htons(atoi(argv[2]));
	ser.sin_addr.s_addr = inet_addr(argv[1]);

	if(connect(sd, (struct sockaddr*)&ser, slen) == -1){
		perror("connect");
		exit(1);
	}

	pthread_create(&snd_thread, NULL, send_msg, (void*)&sd);
	pthread_create(&snd_thread, NULL, send_msg, (void*)&sd);
	gameBoard();
	pthread_join(snd_thread, &thread_return);
	pthread_join(rcv_thread, &thread_return);
	close(sd);
	return 0;
}

void police_colrow{
	int c;
	int delay;
	void move_police(int);

	initscr();
	clear();
	noecho();
	cbreak();

	while(1){
		if(start){
			printf("start\n");
			sleep(0.5);
			break;
		}
	}

	symbol = 'P';
	
	startpoint();

	police_row = 0;
	police_col = 0;
	delay = 500;

	move(startx, starty);
	addch(symbol);
	signal(SIGALRM, move_police);
	signal(SIGQUIT, SIG_IGN);
	set_ticker(delay);

	while(1){
		c = wgetch(menu_win);
		switch(c){
			case KEY_UP:
				police_row = -1;
				police_col = 0;	
				break;
			case KEY_DOWN:
				police_row = -1;
				police_col = 0;	
				break;
			case KEY_RIGHT:
				police_row = -1;
				police_col = 0;	
				break;
			case KEY_LEFT:
				police_row = -1;
				police_col = 0;	
				break;
			case 'Q':
				exit(1);
				break;
		}
	}
	refresh();
	endwin();
	exit(1);
}

void move_police(int s){
	signal(SIGALRM, move_police);

	if(police_col == -1 && MAP[row][col-1] == '*')
		police_col = 0;
	if(police_col == 1 && MAP[row][col+1] == '*')
		police_col = 0;
	if(police_col == -1 && MAP[row-1][col] == '*')
		police_col = 0;
	if(police_col == 1 && MAP[row+1][col] == '*')
		police_col = 0;

	move(row, col);
	viewB(row, col);
	move(row, col);
	addch(BLANK);

	row += police_row;
	col += police_col;

	move(row, col);
	viewM(row, col);
	move(row, col);
	addch(symbol);
	refresh();
}
