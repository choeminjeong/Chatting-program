#include <stdio.h>
#include <stdlib.h>
#include <ncurses.h>

void* send_msg(void *arg){
	int sd = *((int*)arg);
	int len;
	own.who = P;
	while(1){
		own.p_col = col;
		own.p_row = row;
		write(sd, (void*)&own, sizeof(own));
		sleep(0.3);
	}
	return NULL;
}



void* recv_msg(void *arg){
	int sd = *((int*)arg);
	char result[500];
	int str_len;
	int past_r, past_c;

	while(1){
		str_len = read(sd, (void*)&data, sizeof(data));
		start = 1;
		own.t_col = data.t_col;
		own.t_row = data.t_row;
		own.win = data.win;

		if(own.win != 1){
			signal(SIGALRM, SIG_IGN);
			if(own.win == T){
				clear();
				fail(stdscr);
				break;
			}else if(own.win == P){
				clear();
				winner(stdscr);
				break;
			}
		}
		MAP[past_r][past_c] = ' ';

		past_r = data.p_row;
		past_c = data.p_col;

		MAP[past_r][past_c] = 'T';
	}
	return NULL;
}

int main(int argc, char *argv[]){
	int sd;
	struct sockaddr_int ser;
	int slen = sizeof(ser);
	pthread_t snd_thread, rcv_thread, gb_thread, signal_thread;
	
	if(argc != 3){
		printf("Enter to port and IP address");
		exit(1);
	}

	if((sd = socket(AF_INET, SOCK_STREAM, 0)) == -1){
		perror("socket");
		exit(1);
	}

	memset((char *)&ser, '\0', sizeof(ser));
	ser.sin_family = AF_INET;
	ser.sin_port = htons(atoi(argv[2]));
	ser.sin_addr.s_addr = inet_addr(argv[1]);

	if(connect(sd, (struct sockaddr*) &ser, slen) == -1){
		perror("connect");
		exit(1);
	}

	pthread_create(&snd_thread, NULL, send_msg, (void*)&sd);
	pthread_create(&rcv_thread, NULL, recv_msg, (void*)&sd);
	gameBoard();
	pthread_join(snd_thread, &thread_return);
	pthread_join(rcv_thread, &thread_return);
	close(sd);
	return 0;
}
